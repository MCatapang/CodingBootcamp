#pragma warning disable CS8618
using System.ComponentModel.DataAnnotations;
namespace W2D2A1_CRUDelicious.Models;
public class Dish
{
    [Key]
    public int DishId { get; set; }

    [Required(ErrorMessage = "Field can't be empty!")]
    [MinLength(3, ErrorMessage = "Must be at least 3 characters long!")]
    [Display(Name = "Dish Name:")]
    public string Name { get; set; }

    [Required(ErrorMessage = "Field can't be empty!")]
    [MinLength(3, ErrorMessage = "Must be at least 3 characters long!")]
    [Display(Name = "Chef Name:")]
    public string Chef { get; set; }

    [Required(ErrorMessage = "Field can't be empty!")]
    [Range(1, 5, ErrorMessage = "Tastiness must be any value 1-5!")]
    public int Tastiness { get; set; }

    [Required(ErrorMessage = "Field can't be empty!")]
    [Range(1, 10000, ErrorMessage = "Calories must be a positive integer!")]
    public int Calories { get; set; }

    [Required(ErrorMessage = "Field can't be empty!")]
    public string Description { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public DateTime UpdatedAt { get; set; } = DateTime.Now;
}