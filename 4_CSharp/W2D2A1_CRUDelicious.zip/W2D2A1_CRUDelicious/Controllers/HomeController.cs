using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using W2D2A1_CRUDelicious.Models;

public class HomeController : Controller
{
    private MyContext _context;

    public HomeController(MyContext context)
    {
        _context = context;
    }

    [HttpGet("/")]
    public IActionResult Index()
    {
        List<Dish> DishesAll = _context.Dishes
            .OrderByDescending(dish => dish.CreatedAt)
            .ToList();
        ViewBag.DishesAll = DishesAll;
        return View("Index");
    }

    [HttpGet("/new")]
    public IActionResult DishAddForm()
    {
        return View("DishAddForm");
    }

    [HttpGet("/{dishId}")]
    public IActionResult DishOne(int dishId)
    {
        Dish retrievedDish = _context.Dishes.First(
            d => d.DishId == dishId
        );
        return View("DishOne", retrievedDish);
    }

    [HttpGet("/edit/{dishId}")]
    public IActionResult DishEditForm(int dishId)
    {
        Dish retrievedDish = _context.Dishes.First(
            m => m.DishId == dishId
        );
        return View("DishEditForm", retrievedDish);
    }

    [HttpPost("/new")]
    public IActionResult DishAdd(Dish dish)
    {
        if(!ModelState.IsValid)
        {
            return View("DishAddForm");
        }
        _context.Add(dish);
        _context.SaveChanges();
        return Redirect($"/{dish.DishId}");
    }

    [HttpGet("/remove/{dishId}")]
    public IActionResult DishRemove(int dishId)
    {
        Dish retrievedDish = _context.Dishes.First(
            m => m.DishId == dishId
        );
        _context.Dishes.Remove(retrievedDish);
        _context.SaveChanges();
        return RedirectToAction("Index");
    }

    [HttpPost("/{dishId}")]
    public IActionResult DishEdit(Dish editedDish)
    {
        Dish retrievedDish = _context.Dishes.First(
            d => d.DishId == editedDish.DishId
        );
        retrievedDish.Chef = editedDish.Chef;
        retrievedDish.Name = editedDish.Name;
        retrievedDish.Calories = editedDish.Calories;
        retrievedDish.Tastiness = editedDish.Tastiness;
        retrievedDish.Description = editedDish.Description;
        _context.SaveChanges();
        return Redirect($"/{editedDish.DishId}");
    }





    // [HttpGet("/update/{monsterId}")]
    // public IActionResult UpdateMonster(int monsterId, Monster editedMonster)
    // {
    //     Monster retrievedMonster = _context.Monsters.First(
    //         m => m.MonsterId == monsterId
    //     );
    //     retrievedMonster.Name = editedMonster.Name;
    //     retrievedMonster.UpdatedAt = DateTime.Now;

    //     _context.SaveChanges();

    //     return RedirectToAction("Index");
    // }
}