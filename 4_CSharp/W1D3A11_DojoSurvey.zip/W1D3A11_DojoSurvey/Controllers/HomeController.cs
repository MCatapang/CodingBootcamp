using Microsoft.AspNetCore.Mvc;

public class HomeController : Controller
{
    [HttpGet]
    [Route("/")]
    public IActionResult Index()
    {
        return View("Index");
    }

    [HttpPost]
    [Route("FormSubmit")]
    public IActionResult FormSubmit(string name, string location,
    string language, string comment = "N/A")
    {
        Dictionary<string, string> formInfo = new Dictionary<string,string>()
        {
            {"Name", name},
            {"Location", location},
            {"Language", language},
            {"Comment", comment}
        };
        ViewBag.FormInfo = formInfo;
        return View("Result");
    }
}