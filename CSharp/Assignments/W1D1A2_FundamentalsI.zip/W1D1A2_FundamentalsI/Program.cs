﻿// // Print all values from 1-255
// for (int i = 1; i < 256; i++)
// {
//     Console.WriteLine(i);
// }

// // Print values 1-100 divisible by 3 or 5
// for (int i = 1; i <= 100; i++)
// {
//     if (i % 3 == 0 || i % 5 == 0)
//     {
//         Console.WriteLine(i);
//     }
// }

// // Fizz for 3, Buzz for 5, FizzBuzz for 3 & 5
// for (int i = 1; i <= 100; i++)
// {
//     string message = "";
//     if (i % 3 == 0 && i % 5 == 0) message = "FizzBuzz";
//     else if (i % 3 == 0) message = "Fizz";
//     else if (i % 5 == 0) message = "Buzz";
//     if (message != "") Console.WriteLine($"{message} for the number {i}!");
// }

// FizzBuzz in a While Loop
int i = 1;
while (i <= 100)
{
    string message = "";
    if(i % 3 ==0) message += "Fizz";
    if(i%5 == 0) message += "Buzz";
    if (message != "") Console.WriteLine(i + message);
    i++;
}